const s="/assets/png/avatar-g9F9tdKs.png";export{s as _};
